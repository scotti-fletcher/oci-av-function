Content
Sources: [malware-log-source]
Parsers: [malware-results-parser]
Fields: [av-action, av-bucket-name, av-confidence, av-external-link, av-file-size, av-file-type, av-malware-category, av-md5-hash, av-negative-signals, av-object-name, av-object-storage-namespace, av-positive-signals, av-scan-result, av-threat-name]

Reference
Fields: [eventsrc, eventtype, mbody]
